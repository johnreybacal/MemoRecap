var assetID = 0;
var currentPage = 0;
var pageCount = 1;
var assets = [];