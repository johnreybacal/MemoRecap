<form method= "POST" enctype= "multipart/form-data">
	<br/>
	<input type = "file" name = "image" accept = "image/*" id = "imageChooser"/>
	<br/>
	<input type = "submit" name = "imageSubmit" value = "Upload" id = "imageSubmit"/>
</form>